// Helper to get/set state variables from storage
function getStorageData(key, defaultValue) {
  return new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => {
      resolve(result[key] !== undefined ? result[key] : defaultValue);
    });
  });
}

function setStorageData(key, value) {
  return new Promise((resolve) => { 
    chrome.storage.local.set({ [key]: value }, () => {
      resolve();
    });
  });
}

async function fetchWithRetry(url, options = {}, retries = 3, delayMs = 1500) {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url, options);
      if (res.ok) return res;
      if (res.status >= 500 || res.status === 429) {
        console.warn(`[Background Fetch Retry] Status ${res.status} for ${url}. Retrying in ${delayMs}ms...`);
        await new Promise(r => setTimeout(r, delayMs));
        continue;
      }
      return res;
    } catch (err) {
      if (i === retries - 1) throw err;
      console.warn(`[Background Fetch Retry] Error: ${err.message} for ${url}. Retrying in ${delayMs}ms...`);
      await new Promise(r => setTimeout(r, delayMs));
    }
  }
}

function resolveDepopUsernameFromTabs(accessToken) {
  return new Promise((resolve) => {
    const timeoutId = setTimeout(() => {
      console.warn('[Background Worker] resolveDepopUsernameFromTabs timed out.');
      resolve(null);
    }, 1500);

    chrome.tabs.query({}, (tabs) => {
      if (!tabs || tabs.length === 0) {
        console.warn('[Background Worker] No open tabs found at all.');
        clearTimeout(timeoutId);
        resolve(null);
        return;
      }
      
      let resolved = false;
      let pendingQueries = tabs.length;
      
      tabs.forEach((tab) => {
        if (!tab.id) {
          pendingQueries--;
          if (pendingQueries === 0 && !resolved) {
            clearTimeout(timeoutId);
            resolve(null);
          }
          return;
        }
        
        chrome.tabs.sendMessage(tab.id, {
          action: 'RESOLVE_DEPOP_USERNAME_FROM_PAGE',
          token: accessToken
        }, (response) => {
          // Ignore lastError because non-matching tabs will throw a silent connection error
          const err = chrome.runtime.lastError;
          pendingQueries--;
          
          if (response && response.success && response.username) {
            if (!resolved) {
              resolved = true;
              console.log('[Background Worker] Broadcast resolved username from tab ' + tab.id + ':', response.username);
              clearTimeout(timeoutId);
              resolve(response.username);
            }
          }
          
          if (pendingQueries === 0 && !resolved) {
            clearTimeout(timeoutId);
            resolve(null);
          }
        });
      });
    });
  });
}

function fetchUsernameFromBackground(accessToken) {
  const tryFetch = (url) => {
    return fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': accessToken.startsWith('Bearer ') ? accessToken : `Bearer ${accessToken}`,
        'Accept': 'application/json'
      }
    })
    .then(res => {
      if (res.ok) return res.json();
      throw new Error(`Status ${res.status}`);
    });
  };

  return tryFetch('https://webapi.depop.com/api/v1/auth/session/')
    .catch(() => tryFetch('https://webapi.depop.com/api/v1/users/me'))
    .catch(() => tryFetch('https://webapi.depop.com/api/users/me'))
    .then(profile => profile.username || profile.username_canonical || null);
}

// Listener for runtime messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Depop Background received message:', message);
  
  if (message.action === 'START_DEPOP_CONNECT_FLOW') {
    const { token, backendUrl, frontendUrl } = message.data;
    const tabId = sender.tab ? sender.tab.id : null;
    if (tabId) {
      chrome.tabs.update(tabId, { url: 'https://www.depop.com/login/' }, (tab) => {
        const flow = {
          tabId: tab.id,
          token,
          backendUrl,
          frontendUrl
        };
        setStorageData('activeConnectFlow', flow).then(() => {
          console.log('Redirecting same tab for Depop Connect Flow:', tab.id);
          sendResponse({ success: true });
        });
      });
    } else {
      sendResponse({ success: false, message: 'No sender tab found' });
    }
    return true;
  }
  
  else if (message.action === 'GET_CONNECT_FLOW') {
    const tabId = sender.tab ? sender.tab.id : null;
    getStorageData('activeConnectFlow', null).then((flow) => {
      if (flow && flow.tabId === tabId) {
        sendResponse({ success: true, flow });
      } else {
        sendResponse({ success: false });
      }
    });
    return true;
  }
  
  else if (message.action === 'COMPLETE_DEPOP_CONNECT') {
    const { username, userId, accessToken } = message.data;
    getStorageData('activeConnectFlow', null).then((flow) => {
      if (!flow) {
        sendResponse({ success: false, message: 'No active connect flow found' });
        return;
      }
      const { token, backendUrl, frontendUrl } = flow;
      
      // Immediately clear the active flow to prevent duplicate triggers/refreshes
      setStorageData('activeConnectFlow', null);
      
      // Fetch all cookies for depop.com using chrome.cookies API
      chrome.cookies.getAll({ domain: 'depop.com' }, (cookiesList) => {
        const cookieString = (cookiesList || []).map(c => `${c.name}=${c.value}`).join('; ');
        console.log('[Background] Captured cookies string length:', cookieString.length);
 
        console.log('Submitting captured Depop credentials to backend:', backendUrl);
        fetch(`${backendUrl}/depop/connect`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            platform: 'depop',
            username,
            userId,
            accessToken,
            sessionCookie: cookieString
          })
        })
        .then(res => res.json())
        .then((data) => {
          console.log('Backend connect response:', data);
          if (data.success) {
            getStorageData('cachedConnectionDetails', {}).then((cachedDetails) => {
              cachedDetails['depop'] = {
                username,
                userId,
                accessToken,
                sessionCookie: cookieString
              };
              setStorageData('cachedConnectionDetails', cachedDetails).then(() => {
                chrome.tabs.update(flow.tabId, { url: `${flow.frontendUrl}/ebay-accounts?success=depop` });
                sendResponse({ success: true });
              });
            });
          } else {
            sendResponse({ success: false, message: data.message || 'Backend connection failed' });
          }
        })
        .catch(err => {
          console.error('Error connecting Depop to backend:', err);
          sendResponse({ success: false, error: err.message });
        });
      });
    });
    return true;
  }
  
  else if (message.action === 'PING_BACKGROUND') {
    sendResponse({ success: true, message: 'Background worker is active' });
  }
  
  else if (message.action === 'CACHE_CSRF_TOKEN') {
    const { site, token } = message.data;
    if (site && token) {
      getStorageData('cachedCsrfTokens', {}).then((tokens) => {
        tokens[site] = token;
        setStorageData('cachedCsrfTokens', tokens).then(() => {
          console.log(`Cached CSRF Token for ${site}:`, token);
          sendResponse({ success: true });
        });
      });
    } else {
      sendResponse({ success: true });
    }
    return true;
  }
  
  else if (message.action === 'CACHE_CONNECTION_DETAILS') {
    const { platform, data } = message;
    if (platform && data) {
      const proceedCache = (resolvedData) => {
        getStorageData('cachedConnectionDetails', {}).then((cachedDetails) => {
          const existingDetails = cachedDetails[platform];
          if (existingDetails && existingDetails.username && (!resolvedData.username || resolvedData.username === 'depop_user')) {
             console.log('[Background Worker] Retaining existing cached username:', existingDetails.username);
             resolvedData.username = existingDetails.username;
          }
          cachedDetails[platform] = resolvedData;
          setStorageData('cachedConnectionDetails', cachedDetails).then(() => {
            console.log(`Cached Connection Details for ${platform}:`, resolvedData);
            
            // Get cookies for the domain to complete the session data
            const domain = platform === 'depop' ? 'depop.com' : (platform === 'poshmark' ? 'poshmark.com' : '');
            if (domain) {
              chrome.cookies.getAll({ domain }, (cookiesList) => {
                const cookieString = (cookiesList || []).map(c => `${c.name}=${c.value}`).join('; ');
                resolvedData.sessionCookie = cookieString;
                
                // Find any open eLister tabs and post credentials back directly
                chrome.tabs.query({}, (tabs) => {
                  const elisterTabs = (tabs || []).filter(tab => 
                    tab.url && (tab.url.includes('elister.ai') || tab.url.includes('localhost') || tab.url.includes('127.0.0.1'))
                  );
                  
                  elisterTabs.forEach(tab => {
                    chrome.tabs.sendMessage(tab.id, {
                      action: 'ELISTER_CONNECTION_DETAILS_RESPONSE_BG',
                      platform,
                      success: true,
                      data: resolvedData
                    });
                  });
                });
              });
            }

            sendResponse({ success: true });
          });
        });
      };

      if (platform === 'depop' && (!data.username || data.username === 'depop_user')) {
        console.log('[Background Worker] CACHE_CONNECTION_DETAILS: Username missing. Resolving via tabs...');
        resolveDepopUsernameFromTabs(data.accessToken).then(tabUsername => {
          if (tabUsername) {
            console.log('[Background Worker] CACHE_CONNECTION_DETAILS resolved username from tabs:', tabUsername);
            data.username = tabUsername;
            proceedCache(data);
          } else {
            console.log('[Background Worker] CACHE_CONNECTION_DETAILS tab resolution returned null. Falling back to background fetch...');
            fetchUsernameFromBackground(data.accessToken).then(username => {
              if (username) {
                console.log('[Background Worker] Successfully resolved username via background fetch:', username);
                data.username = username;
              }
              proceedCache(data);
            })
            .catch(err => {
              console.error('[Background Worker] Failed to resolve username via background fetch:', err.message);
              data.resolutionError = err.message;
              proceedCache(data);
            });
          }
        });
      } else {
        proceedCache(data);
      }
      return true;
    }
    sendResponse({ success: true });
  }

  else if (message.action === 'GET_CONNECTION_DETAILS') {
    getStorageData('cachedConnectionDetails', {}).then((cachedDetails) => {
      const platformDetails = cachedDetails[message.platform];
      if (platformDetails) {
        const domain = message.platform === 'depop' ? 'depop.com' : (message.platform === 'poshmark' ? 'poshmark.com' : '');
        chrome.cookies.getAll({ domain }, (cookiesList) => {
          const cookieString = (cookiesList || []).map(c => `${c.name}=${c.value}`).join('; ');
          platformDetails.sessionCookie = cookieString;
          
          if (message.platform === 'depop' && (!platformDetails.username || platformDetails.username === 'depop_user')) {
            console.log('[Background Worker] GET_CONNECTION_DETAILS: Username missing. Resolving via tabs...');
            resolveDepopUsernameFromTabs(platformDetails.accessToken).then(tabUsername => {
              if (tabUsername) {
                console.log('[Background Worker] GET_CONNECTION_DETAILS resolved username from tabs:', tabUsername);
                platformDetails.username = tabUsername;
                cachedDetails[message.platform] = platformDetails;
                setStorageData('cachedConnectionDetails', cachedDetails).then(() => {
                  sendResponse({ success: true, data: platformDetails });
                });
              } else {
                console.log('[Background Worker] GET_CONNECTION_DETAILS tab resolution returned null. Falling back to background fetch...');
                fetchUsernameFromBackground(platformDetails.accessToken).then(username => {
                  if (username) {
                    console.log('[Background Worker] Successfully resolved username via background fetch:', username);
                    platformDetails.username = username;
                    cachedDetails[message.platform] = platformDetails;
                    setStorageData('cachedConnectionDetails', cachedDetails);
                  }
                  sendResponse({ success: true, data: platformDetails });
                })
                .catch(err => {
                  console.error('[Background Worker] Failed to resolve username via background fetch:', err.message);
                  platformDetails.resolutionError = err.message;
                  sendResponse({ success: true, data: platformDetails });
                });
              }
            });
          } else {
            sendResponse({ success: true, data: platformDetails });
          }
        });
      } else {
        sendResponse({ success: false });
      }
    });
    return true;
  }
  
  else if (message.action === 'GET_CACHED_CSRF_TOKEN') {
    getStorageData('cachedCsrfTokens', {}).then((tokens) => {
      sendResponse({ success: true, token: tokens[message.site] });
    });
    return true;
  }

  else if (message.action === 'FETCH_DEPOP_PRODUCTS') {
    const { userId, accessToken } = message.data;
    chrome.tabs.query({ url: '*://*.depop.com/*' }, (tabs) => {
      if (tabs && tabs.length > 0) {
        // Send a message to the first open Depop tab to fetch the products
        const activeTab = tabs[0];
        console.log('[Background] Routing FETCH_DEPOP_PRODUCTS to Depop tab:', activeTab.id);
        chrome.tabs.sendMessage(activeTab.id, {
          action: 'FETCH_DEPOP_PRODUCTS_ON_DEPOP',
          userId,
          accessToken
        }, (res) => {
          if (chrome.runtime.lastError) {
            console.error('[Background] Error contacting Depop tab content script:', chrome.runtime.lastError.message);
            sendResponse({ success: false, error: 'Could not contact active Depop tab content script. Make sure Depop page is open.' });
            return;
          }
          sendResponse(res);
        });
      } else {
        console.warn('[Background] No open Depop tab found to broker API request.');
        sendResponse({ 
          success: false, 
          error: 'No active Depop tab found. Please keep a Depop tab open in your browser to sync.' 
        });
      }
    });
    return true;
  }
  
  else if (message.action === 'START_DEPOP_LISTING') {
    const pendingData = message.data;
    setStorageData('pendingListingData', pendingData).then(() => {
      console.log('Stored pending Depop listing data in queue:', pendingData);
      
      // Open Depop create listing page in a new tab
      chrome.tabs.create({ url: 'https://www.depop.com/products/create/' }, (tab) => {
        console.log('Opened Depop tab, ID:', tab.id);
      });
      
      sendResponse({ success: true, message: 'Depop tab opened. Listing queued.' });
    });
    return true;
  }
  
  else if (message.action === 'GET_PENDING_LISTING') {
    getStorageData('pendingListingData', null).then((pendingData) => {
      if (pendingData) {
        sendResponse({ success: true, data: pendingData });
        setStorageData('pendingListingData', null).then(() => {});
      } else {
        sendResponse({ success: false, message: 'No pending listing queued.' });
      }
    });
    return true;
  }
  
  else if (message.action === 'LOG_CAPTURED_API') {
    // Broadcast captured API metrics to popup logs
    chrome.runtime.sendMessage(message).catch(() => {
      // Silently catch error if popup is closed
    });
  }

  else if (message.action === 'BACKGROUND_DEPOP_REQUEST') {
    const { url, method, headers, body, responseType } = message.data;
    const fetchOptions = {
      method: method || 'GET',
      headers: headers || {},
      credentials: 'include'
    };

    if (body) {
      if (typeof body === 'string') {
        fetchOptions.body = body;
      } else if (body.type === 'base64') {
        try {
          const binaryString = atob(body.data);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          fetchOptions.body = bytes;
        } catch (e) {
          console.error("Failed to decode base64 body:", e);
        }
      }
    }

    fetch(url, fetchOptions)
      .then(async (res) => {
        const ok = res.ok;
        const status = res.status;
        let resData = null;

        if (responseType === 'json') {
          resData = await res.json().catch(() => null);
        } else if (responseType === 'blob' || responseType === 'base64') {
          const arrayBuffer = await res.arrayBuffer().catch(() => new ArrayBuffer(0));
          const bytes = new Uint8Array(arrayBuffer);
          let binary = '';
          const len = bytes.byteLength;
          for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
          }
          resData = btoa(binary);
        } else {
          resData = await res.text().catch(() => null);
        }

        sendResponse({ success: true, ok, status, data: resData });
      })
      .catch((err) => {
        console.error('Background fetch failed:', err);
        sendResponse({ success: false, error: err.message });
      });

    return true; // Keep channel open
  }

  else if (message.action === 'RELOAD_ELISTER_TABS') {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        if (tab.url && (tab.url.includes('elister.ai') || tab.url.includes('localhost') || tab.url.includes('127.0.0.1'))) {
          console.log('Reloading tab:', tab.id, tab.url);
          chrome.tabs.reload(tab.id);
        }
      });
    });
    sendResponse({ success: true });
  }
  
  else if (message.action === 'PUBLISH_DEPOP_BACKGROUND') {
    const { listing, token } = message.data;
    
    console.log('[Background] Fetching active cookies for depop.com...');
    chrome.cookies.getAll({ domain: 'depop.com' }, (cookies) => {
      const cookieString = (cookies || []).map(c => `${c.name}=${c.value}`).join('; ');
      console.log('[Background] Injecting Cookie header dynamically (length:', cookieString.length, ')');

      const ruleId = 1;
      const rule = {
        id: ruleId,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'Cookie', operation: 'set', value: cookieString }
          ]
        },
        condition: {
          urlFilter: '||webapi.depop.com',
          initiatorDomains: [chrome.runtime.id]
        }
      };

      chrome.declarativeNetRequest.updateSessionRules({
        removeRuleIds: [ruleId],
        addRules: [rule]
      }, () => {
        console.log('[Background] Session rules updated. Initiating direct publish...');
        publishDepopBackground(listing, token)
          .then((result) => {
            // Clean up rule
            chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId] });
            sendResponse(result);
          })
          .catch((err) => {
            // Clean up rule
            chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ruleId] });
            sendResponse({ success: false, error: err.message });
          });
      });
    });
      
    return true;
  }
  
  return true; // Keep channel open
});

async function publishDepopBackground(listing, token) {
  try {
    console.log('[Background Publisher] Initializing publish for listing:', listing.title);

    // Step 1: Upload Images
    const pictureIds = [];
    const images = listing.images || [];

    for (let i = 0; i < images.length; i++) {
      try {
        console.log(`[Background Publisher] Downloading image ${i + 1} of ${images.length}...`);
        const cleanUrl = images[i].replace('//localhost:', '//127.0.0.1:');
        const imgRes = await fetchWithRetry(cleanUrl);
        if (!imgRes.ok) throw new Error(`Failed to download image: Status ${imgRes.status}`);
        const imgBlob = await imgRes.blob();

        console.log(`[Background Publisher] Initializing image upload ${i + 1} on Depop...`);
        const initRes = await fetchWithRetry('https://webapi.depop.com/api/v4/pictures/', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token.startsWith('Bearer ') ? token : `Bearer ${token}`
          },
          body: JSON.stringify({
            type: "product",
            extension: "jpg",
            dimensions: { width: 1280, height: 1280 }
          }),
          credentials: 'include'
        });

        if (!initRes.ok) {
          const errBody = await initRes.text().catch(() => '');
          throw new Error(`Failed to initialize picture upload: Status ${initRes.status}. Details: ${errBody}`);
        }

        const initData = await initRes.json();
        const photoId = initData.id || initData.picture_id || initData.pictureId || initData.sid;
        const uploadUrl = initData.url || initData.upload_url || initData.uploadUrl;

        if (!photoId || !uploadUrl) {
          throw new Error(`Invalid response structure: ${JSON.stringify(initData)}`);
        }

        console.log(`[Background Publisher] Uploading image ${i + 1} to S3...`);
        const putRes = await fetchWithRetry(uploadUrl, {
          method: 'PUT',
          headers: {
            'Content-Type': 'image/jpeg'
          },
          body: imgBlob
        });

        if (!putRes.ok) {
          throw new Error(`Failed to upload image to S3: Status ${putRes.status}`);
        }

        pictureIds.push(photoId);
        console.log(`[Background Publisher] Upload success for image ${i + 1}. ID: ${photoId}`);
      } catch (imgErr) {
        console.error(`[Background Publisher] Failed to upload image ${i + 1}:`, imgErr.message);
        throw new Error(`Depop Image Upload Failed: ${imgErr.message}`);
      }
    }

    if (pictureIds.length === 0) {
      throw new Error('No images were successfully uploaded to Depop.');
    }

    // Step 2: Resolve Listing Attributes
    const mapCondition = (cond) => {
      const c = String(cond || '').toLowerCase();
      if (c.includes('brand_new') || c.includes('brand new') || c.includes('nwt')) return 'brand_new';
      if (c.includes('like_new') || c.includes('like new') || c.includes('nwot') || c.includes('used_like_new')) return 'used_like_new';
      if (c.includes('excellent')) return 'used_excellent';
      if (c.includes('good') || c.includes('very_good') || c.includes('very good') || c.includes('used_good')) return 'used_good';
      if (c.includes('fair') || c.includes('used_fair')) return 'used_fair';
      return 'used_excellent';
    };

    const mapColor = (col) => {
      if (!col) return [];
      const c = String(col).toLowerCase().trim();
      if (c.includes('navy')) return ['blue'];
      if (c.includes('gray')) return ['grey'];
      if (c.includes('multi')) return ['multi'];
      const validColors = ['black', 'white', 'blue', 'red', 'green', 'grey', 'pink', 'purple', 'brown', 'yellow', 'orange', 'silver', 'gold', 'multi', 'cream', 'beige', 'tan'];
      for (const vc of validColors) {
        if (c.includes(vc)) return [vc];
      }
      return [];
    };

    const mapProductType = (cat) => {
      if (!cat) return 'shirts';
      const c = String(cat).toLowerCase().trim();
      if (c.includes('t-shirt') || c.includes('tshirt') || c.includes('tee')) return 'tshirts';
      if (c.includes('shirt') || c.includes('top')) return 'shirts';
      if (c.includes('jacket') || c.includes('coat')) return 'jackets';
      if (c.includes('hoodie') || c.includes('sweatshirt')) return 'sweatshirts';
      if (c.includes('sweater') || c.includes('jumper')) return 'jumpers';
      if (c.includes('jean')) return 'jeans';
      if (c.includes('trouser') || c.includes('pant')) return 'trousers';
      if (c.includes('short')) return 'shorts';
      if (c.includes('skirt')) return 'skirts';
      if (c.includes('dress')) return 'dresses';
      if (c.includes('shoe') || c.includes('sneaker') || c.includes('boot') || c.includes('trainer')) return 'trainers';
      return c.replace(/[^a-z0-9]/g, '') || 'shirts';
    };

    const getGender = (cat) => {
      const c = String(cat || '').toLowerCase();
      if (c.includes('women')) return 'female';
      if (c.includes('men')) return 'male';
      return 'unisex';
    };

    const getCurrency = (code) => {
      if (code === 'GB' || code === 'UK') return 'GBP';
      if (code === 'AU') return 'AUD';
      if (code === 'CA') return 'CAD';
      if (['AT','BE','CY','EE','FI','FR','DE','GR','IE','IT','LV','LT','LU','MT','NL','PT','SK','SI','ES'].includes(code)) return 'EUR';
      return 'USD';
    };

    const mapBrand = (brandStr) => {
      if (!brandStr) return null;
      const b = String(brandStr).trim().toLowerCase();
      if (!b) return null;
      
      const brandMap = {
        'eagle': 'american-eagle',
        'american eagle': 'american-eagle',
        'ae': 'american-eagle',
        'nike': 'nike',
        'adidas': 'adidas',
        'zara': 'zara',
        'h&m': 'hm',
        'hm': 'hm',
        'urban outfitters': 'urban-outfitters',
        'uo': 'urban-outfitters',
        'shein': 'shein',
        'brandy melville': 'brandy-melville',
        'levi\'s': 'levis',
        'levis': 'levis',
        'champion': 'champion',
        'pacsun': 'pacsun',
        'tommy hilfiger': 'tommy-hilfiger',
        'ralph lauren': 'ralph-lauren',
        'polo ralph lauren': 'ralph-lauren',
        'gucci': 'gucci',
        'supreme': 'supreme',
        'stussy': 'stussy',
        'north face': 'the-north-face',
        'the north face': 'the-north-face',
        'vintage': 'vintage'
      };

      if (brandMap[b]) return brandMap[b];
      const slug = b.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
      return slug || null;
    };

    let shippingMethods = [];
    let sellerAddress = "United States";
    let sellerGeo = { lat: 37.09024, lng: -95.712891 };
    let sellerCountry = "US";

    try {
      console.log('[Background Publisher] Fetching seller addresses...');
      const bearerHeader = token.startsWith('Bearer ') ? token : `Bearer ${token}`;
      const addrRes = await fetchWithRetry('https://webapi.depop.com/api/v1/shop/seller-addresses/', {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Authorization': bearerHeader
        },
        credentials: 'include'
      });

      if (addrRes.ok) {
        const addrData = await addrRes.json();
        const addresses = Array.isArray(addrData) ? addrData : (addrData?.addresses || addrData?.results || []);
        if (addresses && addresses.length > 0) {
          const activeAddress = addresses[0];
          const addressId = activeAddress.id || activeAddress.address_id;
          
          sellerAddress = activeAddress.city || activeAddress.town || "United States";
          sellerCountry = activeAddress.country || "US";
          sellerGeo = {
            lat: activeAddress.geo_position_lat || 37.09024,
            lng: activeAddress.geo_position_lng || -95.712891
          };

          if (sellerCountry === 'US') {
            shippingMethods = [{
              payer: 'buyer',
              parcel_size: 'under_1lb',
              shipping_provider_id: 'USPS',
              ship_from_address_id: addressId
            }];
          } else if (sellerCountry === 'GB') {
            shippingMethods = [{
              payer: 'buyer',
              parcel_size: 'medium',
              shipping_provider_id: 'Evri',
              ship_from_address_id: addressId
            }];
          }
        }
      }
    } catch (shipErr) {
      console.error('[Background Publisher] Failed to resolve shipping details dynamically:', shipErr.message);
    }

    const currency = getCurrency(sellerCountry);
    const gender = getGender(listing.category);
    const mappedBrand = mapBrand(listing.brand);

    // Build listing creation payload
    const savePayload = {
      age: listing.age ? [listing.age.toLowerCase()] : ["modern"],
      address: sellerAddress,
      attributes: (() => {
        const attrs = {};
        if (listing.occasion) {
          const cleanOcc = listing.occasion.toLowerCase();
          const occMap = { 'casual': 'daytime', 'party': 'celebration', 'going out': 'going-out-evening', 'formal': 'special-occasion', 'sports': 'sport-workout', 'workout': 'sport-workout', 'business': 'work', 'vacation': 'holiday' };
          attrs["occasion"] = [occMap[cleanOcc] || cleanOcc];
        }
        if (listing.material) attrs["material"] = [listing.material.toLowerCase()];
        if (listing.bodyFit) {
          const bf = listing.bodyFit.toLowerCase();
          if (gender === 'female' || bf !== 'petite') {
            attrs["body-fit"] = [bf];
          }
        }
        if (listing.fastening) attrs["fastening"] = [listing.fastening.toLowerCase()];
        
        if (listing.fit) {
          const fitVal = listing.fit.toLowerCase();
          const catId = (listing.categoryId || '').toLowerCase();
          const isBottoms = catId.includes('bottom') || catId.includes('jeans') || catId.includes('trousers') || catId.includes('skirt') || catId.includes('shorts') || catId.includes('jogger');
          if (isBottoms) {
            attrs["bottom-fit"] = [fitVal];
          } else {
            attrs["size-fit"] = [fitVal];
          }
        }
        
        const catId = (listing.categoryId || '').toLowerCase();
        if (catId.includes('coat') || catId.includes('jacket')) {
          attrs["coat-type"] = [listing.depopType ? listing.depopType.toLowerCase() : "other-coats-jackets"];
        } else if (listing.depopType) {
          const typeVal = listing.depopType.toLowerCase();
          if (catId.includes('bottom') || catId.includes('jeans') || catId.includes('trousers') || catId.includes('shorts')) {
            attrs["bottom-style"] = [typeVal];
          } else if (catId.includes('footwear') || catId.includes('shoes') || catId.includes('trainers') || catId.includes('boots')) {
            attrs["trainers-type"] = [typeVal];
          }
        }
        return attrs;
      })(),
      boost: { status: "inactive" },
      colour: mapColor(listing.color),
      condition: mapCondition(listing.selectedCondition || listing.conditionId),
      country: sellerCountry,
      description: listing.description || '',
      gender: gender,
      geo_position_lat: sellerGeo.lat,
      geo_position_lng: sellerGeo.lng,
      is_kids: String(listing.category || '').toLowerCase().includes('kids'),
      listing_lifecycle_id: crypto.randomUUID(),
      national_shipping_cost: parseFloat(listing.shippingPrice || 0).toFixed(2),
      picture_ids: pictureIds,
      price_amount: parseFloat(listing.price || 0).toFixed(2),
      price_currency: currency,
      product_type: mapProductType(listing.categoryId || listing.category),
      shipping_methods: shippingMethods,
      sku: listing.sku || `KL${Date.now()}`,
      source: listing.source ? [listing.source.toLowerCase()] : ["preloved"],
      style: listing.styleTag ? listing.styleTag.split(',').map(s => s.trim().toLowerCase()).filter(Boolean) : ["casual"],
      variant_set: (() => {
        if (listing.size) {
          const match = String(listing.size).match(/^(\d+)\.([\d.]+)-(\w+)$/);
          if (match) return parseInt(match[1]);
        }
        return 54;
      })(),
      variants: (() => {
        const qty = parseInt(listing.quantity) || 1;
        if (listing.size) {
          const match = String(listing.size).match(/^(\d+)\.([\d.]+)-(\w+)$/);
          if (match) {
            return { [match[2]]: qty };
          }
          const sizeName = String(listing.size).trim().toUpperCase();
          const standardSizes = {
            'XXS': '1', 'XS': '2', 'S': '3', 'M': '4', 'L': '5', 'XL': '6', 'XXL': '7', '3XL': '8', '4XL': '9',
            'ONE SIZE': '90', 'OS': '90'
          };
          if (standardSizes[sizeName]) {
            return { [standardSizes[sizeName]]: qty };
          }
        }
        return { "4": qty }; // Default M
      })(),
      persistent_id: crypto.randomUUID(),
      quantity: 1
    };

    if (mappedBrand) {
      savePayload.brand = mappedBrand;
    }

    console.log('[Background Publisher] Step 2: Creating listing on Depop...');
    const saveRes = await fetchWithRetry('https://webapi.depop.com/presentation/api/v1/listing/products/', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': token.startsWith('Bearer ') ? token : `Bearer ${token}`
      },
      body: JSON.stringify(savePayload),
      credentials: 'include'
    });

    if (!saveRes.ok) {
      const errBody = await saveRes.json().catch(() => null);
      const details = errBody?.message || JSON.stringify(errBody);
      throw new Error(`Depop Save Failed: ${details}`);
    }

    const savedData = await saveRes.json();
    console.log('[Background Publisher] Listing saved successfully on Depop!');
    
    const depopId = savedData.id || '';
    const depopSlug = savedData.slug || '';
    const depopUrl = depopSlug ? `https://www.depop.com/products/${depopSlug}/` : `https://www.depop.com/products/${depopId}/`;

    return {
      success: true,
      id: String(depopId),
      url: depopUrl
    };
  } catch (err) {
    console.error('[Background Publisher] Failed to publish on Depop:', err.message);
    return { success: false, error: err.message };
  }
}
